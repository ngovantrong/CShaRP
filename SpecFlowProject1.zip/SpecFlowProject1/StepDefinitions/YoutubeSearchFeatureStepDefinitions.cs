using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using TechTalk.SpecFlow;

namespace SpecFlowProject1.StepDefinitions
{
    [Binding]
    public class YoutubeSearchFeatureStepDefinitions
    {
        private IWebDriver driver;
        public YoutubeSearchFeatureStepDefinitions(IWebDriver driver)
        {
            this.driver = driver;
        }
 

        [Given(@"Open the browser")]
        public void GivenOpenTheBrowser()
        {
            //driver = new ChromeDriver();
            //driver.Manage().Window.Maximize();
        }

        [When(@"Enter the URL")]
        public void WhenEnterTheURL()
        {
            driver.Url = "https://www.youtube.com/";
            Thread.Sleep(1000);
        }

        [Then(@"Search for the Testers Talk")]
        public void ThenSearchForTheTestersTalk()
        {
            driver.FindElement(By.XPath("//*[@NAME='search_query']")).SendKeys("Testers Talk");
            driver.FindElement(By.XPath("//*[@NAME='search_query']")).SendKeys(Keys.End);
            //Thread.Sleep(5000);
            driver.Quit();
        }
    }
}
