using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace SpecFlowProject1.StepDefinitions
{
    [Binding]
    public class DataTableDataDrivenTestingStepDefinitions
    {
        private IWebDriver driver;
        public DataTableDataDrivenTestingStepDefinitions(IWebDriver driver)
        {
            this.driver = driver;
        }

        [Then(@"Enter search keyword in Youtube")]
        public void ThenEnterSearchKeywordInYoutube(Table table)
        {
            var searchCriteria = table.CreateSet<SearchKeyTestData>();

            foreach (var keyword in searchCriteria)
            {
                driver.FindElement(By.XPath("//*[@NAME='search_query']")).Clear();
                driver.FindElement(By.XPath("//*[@NAME='search_query']")).SendKeys(keyword.searchKey);
                driver.FindElement(By.XPath("//*[@NAME='search_query']")).SendKeys(Keys.Enter);
                Thread.Sleep(1000);
            }
        }

    }

    public class SearchKeyTestData
    {
        public string searchKey { get; set; }
    }

}
