using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using TechTalk.SpecFlow;

namespace SpecFlowProject1.StepDefinitions
{
    [Binding]
    public class ExamplesDataDrivenTestingStepDefinitions
    {
        private IWebDriver driver;
        public ExamplesDataDrivenTestingStepDefinitions(IWebDriver driver)
        {
            this.driver = driver;
        }

        [Then(@"Search with (.*)")]
        public void ThenSearchWithSpecflowByTestersTalk(string searchKey)
        {
            driver.FindElement(By.XPath("//*[@NAME='search_query']")).SendKeys(searchKey);
            driver.FindElement(By.XPath("//*[@NAME='search_query']")).SendKeys(Keys.Enter);
            //Thread.Sleep(5000);
        }


    }
}
